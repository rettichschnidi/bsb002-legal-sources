var structlws__tokens =
[
    [ "token", "structlws__tokens.html#a9f3635412bc71a5cb78e9862b55f10cd", null ],
    [ "token_len", "structlws__tokens.html#a855b7375d1d58516c0ecd4b60e9a7766", null ]
];